﻿define m = Character("Eufrid", callback=make_blips({
    "talk": "audio/SFX_Vox_Eufrid_Talk_P01.FLAC",
    "yell": "audio/SFX_Vox_Eufrid_Yell_P01.FLAC"
}))

define c = Character("Cordula", callback=make_blips({
    "talk": "audio/SFX_Vox_Cordula_Talk_P02.OGG",
    "yell": "audio/SFX_Vox_Cordula_Yell_P02.OGG"
}))


define e = Character("Emil", callback=make_blips({
    "talk": "audio/SFX_Vox_Emil_Talk_P02.FLAC",
    "yell": "audio/SFX_Vox_Emil_Yell_P01.FLAC"
}))

define s = Character("Siofra", callback=make_blips({
    "talk": "audio/SFX_Vox_Siofra_Talk_P02.OGG",
    "yell": "audio/SFX_Vox_Siofra_Yell_P02.OGG"
}))

define w = Character ("Walaram", callback=make_blips({
    "talk": "audio/SFX_Vox_Eufrid_Talk_P01.FLAC",
    "yell": "audio/SFX_Vox_Eufrid_Yell_P01.FLAC"
}))

define em = Character("Emil & Eufrid", callback=make_blips({
    "talk": "audio/SFX_Vox_Eufrid_Talk_P01.FLAC",
    "yell": "audio/SFX_Vox_Eufrid_Yell_P01.FLAC"
}))

define v = Character ("Man", callback=make_blips({
    "talk": "audio/SFX_Vox_Eufrid_Talk_P01.FLAC",
    "yell": "audio/SFX_Vox_Eufrid_Yell_P01.FLAC"
}))

define ow = Character ("Old Woman", callback=make_blips({
    "talk": "audio/SFX_Vox_Eufrid_Talk_P01.FLAC",
    "yell": "audio/SFX_Vox_Eufrid_Yell_P01.FLAC"
}))

define om = Character ("Old Man", callback=make_blips({
    "talk": "audio/SFX_Vox_Eufrid_Talk_P01.FLAC",
    "yell": "audio/SFX_Vox_Eufrid_Yell_P01.FLAC"
}))

define t = Character ("Visitor", callback=make_blips({
    "talk": "audio/SFX_Vox_Eufrid_Talk_P01.FLAC",
    "yell": "audio/SFX_Vox_Eufrid_Yell_P01.FLAC"
}))

define yw = Character ("Young Woman", callback=make_blips({
    "talk": "audio/SFX_Vox_Eufrid_Talk_P01.FLAC",
    "yell": "audio/SFX_Vox_Eufrid_Yell_P01.FLAC"
}))

define wm = Character ("Watchman", callback=make_blips({
    "talk": "audio/SFX_Vox_Eufrid_Talk_P01.FLAC",
    "yell": "audio/SFX_Vox_Eufrid_Yell_P01.FLAC"
}))

image Emil happy = "Emil.png"
image Emil sad = "EmilSad.png"
image Emil smirk = "EmilSmirk.png"
image Emil grim = "EmilGrim.png"

image Siofra = "Siofra.png"
image Siofra open = "SiofraOpen.png"

image Cordula happy = "Cordula1.png"
image Cordula surprised = "CordulaSurprised.png"
image Cordula open = "CordulaOpen.png"
image Cordula frown = "CordulaFrown.png"

image Walaram happy = "Walhappy.png"
image Walaram surprised = "Walconcern.png"
image Walaram question = "WalMog.png"
image Walaram concern  = "WalNeutral.png"

image drunk = "images/DrunkMan.png"
image bakery1 = "images/BakeryFinal.png"
image Bakery_Night = "images/BakeryNight.png"
image nothing = "images/Blank.jpg"
image town = "images/Stalls2.png"
image start = "images/PlaceholderStart.png"
image Fountain = "images/fountain2.png"
image Fountain_Night = "images/Fountain1.png"
image Stalls = "images/Stalls2.png"
image Stalls_Night = "images/Stalls1.png"
image Lake = "images/Lake1.png"
image Lake_Cordula = "images/Lake_Cordula.png"
image Forest = "images/Forest.png"
image Forest_Night = "images/Forest2.png"
image Field = "images/Field.png"
image Field_Night = "images/Field_Night.png"

define audio.towntune = "audio/MX_Town_loop.OGG"
define audio.festivaltune = "audio/MX_Festival_Draft1.mp3"
define audio.sirensong = "audio/VO_Siren_01.ogg"

default visited = set()
default investigated = set()
default did_bakery = False
default did_cordula = False
default did_wander = False
default did_stay = False
default Lake = False
default Noises = False
default ElderlyWoman = False
default WorkingMan = False
default YoungVisitor = False
default Second = False
default Lake2 = False
default Noises2 = False
default investigated2 = set()
default investigated3 = set()
default Lake3 = False
default Noises3 = False
default mayor = False
default cat = False
default youngwoman = False
default Drunk = False
default EmilDay3 = False
default Search_Bakery = False
default Search_Town = False
default oldCouple = False
default Watchman = False
default WalaramSearch = False
# SCREENS 

screen Bakery_Night():
    imagemap:
        ground "images/BakeryNight.png"
        hotspot (953, 589, 190, 263) action Return ("Candles") tooltip "Candles"
        hotspot (1682, 153, 237, 850) action Return ("Doorway") tooltip "Doorway"
        hotspot (0, 30, 963, 813) action Return ("BakedGoods") tooltip "Baked Goods"
    
    $ tooltip = GetTooltip()
    if tooltip:
        text "[tooltip]" xalign 0.5 yalign 0.75

screen Lake_Cordula():
    imagemap:
        ground "images/Lake_Cordula.png"
        hotspot (870, 567, 422, 173) action Return ("Cordula") tooltip "?"
        hotspot (3, 274, 910, 366) action Return("Fence2") tooltip "Fence"
        hotspot (646, 26, 1245, 428) action Return ("Forest2") tooltip "Forest"

    $ tooltip = GetTooltip()
    if tooltip:
        text "[tooltip]" xalign 0.5 yalign 0.75

screen forest_path():
    imagemap:
        ground "images/BakeryFinal.png"
        hotspot (233, 345, 419, 191) action Return("Bread")      tooltip "Bread"
        hotspot (660, 164, 406, 177) action Return("Jars")       tooltip "Jars"
        hotspot (664, 628, 372, 108) action Return("Pastries")   tooltip "Pastries"
        hotspot (0, 611, 394, 247)   action Return("FreshBread") tooltip "Fresh Bread"

    $ tooltip = GetTooltip()
    if tooltip:
        text "[tooltip]" xalign 0.5 yalign 0.75

# START OF GAME
label start:
    "Freedom and Life are earned by those alone who conquer them each day anew."
    "To live is to keep moving forward, no matter what."
    "The world does not wait for anyone."
    m "..."
    "You need to get moving"
    m "..."
    "There is no point in standing around."
    m "..."

    jump town

label town: 
    scene town with fade
    play music towntune fadein 1.0
    "The year was 18xx. The town of Kleinsee was busy preparing for its biggest event of the year. The Mid-Autumn Festival."
    "The festival brought in guests from all across the country."
    "The Mid-Autumn Festival was a yearly event that took place over the course of three days. It was full of local foods and fun."
    "On the final day, there is a large dance that involves both the townsfolk and any visitors. That was what made the final day the most popular."

    m "And with that preparations for tomorrow are complete!" (cb_mood="yell")
    "I had just finished up all my prep work for the festival. This year I was helping my parents with their stall for the festival."
    "I normally just had a minor vending role but this year they let me participate in the whole set-up. I felt a bit nervous, but was ready for this new role."
    m "Now that I have some free time I might as well wander around for a bit."

label town_menu:
    if did_bakery and did_cordula and did_wander and did_stay:
        jump MeetUp1

    menu:
        "Now that I had some free time I wanted to"

        "Go to the bakery" if not did_bakery:
            $ did_bakery = True
            jump bakery

        "Look for Cordula" if not did_cordula:
            $ did_cordula = True
            jump Search_Cordula

        "Wander around the town" if not did_wander:
            $ did_wander = True
            jump wander
        
        "Take a break" if not did_stay:
            $ did_stay = True
            jump StayHere
   

   
label Search_Cordula:
"Cordula was a friend I have had ever since my childhood. She moved to Kleinsee when she was eight, and we had been friends ever since."
"She spent most of her free time around the fountain. It was there that she liked to play her Harmonica for tips."
play audio "audio/SFX_footstep_dirt.FLAC"
scene Fountain
"Cordula was gracefully playing her Harmonica in the middle of the fountain square. She had garnered a small crowd."
# Add sound effects here. Some for crowd + possibly find a harmonica track.
"I watched her for a couple of minutes, enjoying the serene music, until she reached the end of her song. She then looked up and finally noticed me."

show Cordula happy
c "To what do I owe the pleasure?"
"Cordula gave me a sly look."
m "I just finished all my preparations and wanted to see something more exciting."
show Cordula open
c "I think anything is more exciting than setting up a table all day."
m "That's why I came to see you and not anyone else."
show Cordula open with vpunch
"Cordula gave me a playful shove." 
c "How did the setup for your parents' stall go?"
m "It was surprisingly simple. I just had to make sure the main stars of our stall were all front and center. "
m "For the placement of everything else I just played it by eye."
c "I can't wait to see it tomorrow. Are you working all the time the whole day tomorrow?"
m "Unfortunately, yes. I am working from dawn to dusk tomorrow."
show Cordula frown
c "Hm... It will at least be exciting. I have already heard talk of visitors arriving."
m "It will be a lot of work. I just hope I will have some downtime at some point."
c "Again, at least you will be busy. You won't just be standing around all day waiting for a customer to appear."
m "I suppose that you could look at it that way."
m "Either way, I have a lot to think about."
"I started to leave."
c "See you later tonight!" (cb_mood="yell")
hide Cordula with dissolve

jump town_menu



label wander:
scene Stalls with fade
"I went to look at the rest of the festival stalls. I hadn't been able to get a look at any while I was setting up our stall."
"This year the amount of stalls doubled. It seemed like the mayor really wanted to make sure this year had a big turnout."
"I heard he had even reached out to foreign vendors, which is why the stall numbers had doubled. I was curious to see what these new vendors had up their sleeve."
"I moved towards one of the new vendors. When I was preparing I caught a glimpse of this stall. It was full of curiosities such that I had never seen before." 
"As I got closer to the stall I noticed the vendor. She was also unlike anything I had seen before." 
show Siofra
"She had ghastly features and sunken in skin. I could smell a bit of a stale odor coming from her. It fit her stall in some way, an odd person for an odd stall."
"The vendor looked up at me and I felt a chill run through my body. She seemed a little irate."
s "..."
m "...Good afternoon. I'm Eufrid. I'm also a vendor here. My stall is right down the way."
"I pointed towards the town center. My family had gotten a decent spot this year, despite all the new entries."
show Siofra open
s "I see..."
"I frowned a bit. It didn't seem like this woman was one for conversation." 
show Siofra
m "What's your name? I don't think I have seen you around these parts before." 
"I tried to keep being friendly. I wanted to make sure we left an impression on all the newcomers here, hopefully that meant they would want to return next year."
show Siofra open
s "...Siofra."
show Siofra
"An interesting name to say the least. I had never heard of such a name before this." 
m "Well, 'tis nice to meet you, Siofra. Hopefully, I'll have some free time to check out your stall during the festival."
"Siofra gave a slight smile."
show Siofra open
s "I hope so as well."
hide Siofra with dissolve
"The way she smiled frightened me a bit. It reminded me of a rabid horse I had a run-in with as a child." 
"But I wasn't one to judge off of appearances, so I tried to keep that thought out of my mind."
# See if players like openish mouth for each time character is speaking. 

jump town_menu

label StayHere:
    scene town
"I went and went towards a bench on the side of the walkway."
"I sat around in wait for a long while, just watching people go by."
"After a while a man approached me."
show Walaram happy
w "How might you be doing today?"
"This man was Walaram, he had moved to Kleinsee a little over a year ago after finishing at University."
"He is one of the main writers in our local newspaper. Who knows why someone with such a prestigious degree ended up in this town."
"There were a lot of people in our town who weren't too fond of him. I somewhat tolerated him, so he gravitated towards me."
m "I'm doing just fine. How about yourself?"
"I personally wasn't a huge fan of Walaram's personality. He was always prying. I found it rather annoying."
# This might not make sense.
show Walaram question
w "I'm doing dandy as usual, but I was wondering something?"
"{i}Here we go. Time for what he really wants...{/i}"
m "What is it?"
"I gave him an annoyed look, but I doubted he would care how I felt right now."
show Walaram surprised
w "Have you heard any interesting rumors lately, what with the upcoming festival and all?"
"Yes, this was the type of person he was. He was always on the hunt for a scoop."
m "No, I spent most of the day working. I didn't have time to see anything interesting."
show Walaram concern
w "Hmm, I see."
show Walaram question
w "Well then, I'll be off!" (cb_mood="yell")
hide Walaram with dissolve
"He left with haste, leaving me alone once again."

jump town_menu


label bakery:
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene bakery1

label bakery_loop:
    call screen forest_path
    $ spot = _return

    if spot == "Bread":
        m "{i}Wow, it looks like they are prepping a lot.{/i}"
        m "{i}I guess it makes sense, the festival starts tomorrow...{/i}"
        m "{i}Maybe I should've done more prep...{/i}"

    elif spot == "Jars":
        m "{i}I see these jars everyday yet I still don't know what they are for.{/i}"

    elif spot == "Pastries":
        m "{i}Wow, that smells divine.{/i}"
        m "{i}I wonder if they could sneak me a piece...{/i}"

    elif spot == "FreshBread":
        m "{i}Looks freshly made.{/i}"
        m "{i}I wonder if they made it.{/i}"

    $ visited.add(spot)

    if len(visited) == 4:
        jump all_viewed

jump bakery_loop

label all_viewed:
    m "{i}They don't seem to be coming back anytime soon. I should probably leave.{/i}"
    play audio "audio/Door.mp3"
    m "?"
    show Emil happy with fade 
    e "Good afternoon Eufrid. What are you doing here?"
    "This is just the person I was looking for."
    "This is Emil. We have known each other since we were kids."
    "He has been working at the bakery since he was fourteen. If he's feeling nice he will sneak Cordula and me some treats."
    show Emil sad
    e "Eufrid...?"
    m "Sorry, what were you saying?"
    show Emil happy
    e "I was just asking you what you are doing here."
    
    menu:
        "How should I respond"

        "Just wandering around":
            show Emil smirk
            e "I guess that makes sense."
            m "Well, I guess I should get a move on. Wouldn't want to distract you."
            e "Don't worry about it! It was nice to see you!" (cb_mood="yell")

        "None of your business":
            show Emil grim
            e "What do you mean none of my business?!" (cb_mood="yell")
            m "I don't think your boss would agree with that."
            e "That's not the point right now. Stop messing around."
            m "I was just wandering around. Don't be so dramatic."
            m "I was just about to leave anyways."
            e "Okay... see you later."

        "Nothing":
            show Emil grim
            e "Doesn't seem like nothing. But who am I to judge?"
            m "Yeah. Who are you to judge?"
            show Emil sad
            e "... I'm just gonna get back to work."
            m "{i}I guess that means I should leave.{/i}"


label after_chat:
    m "Bye! See you tonight!" (cb_mood="yell")
    hide Emil with fade
    jump town_menu

label MeetUp1:
    stop music fadeout 1.0
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Fountain_Night with fade
"After all that excitement, it was almost dusk. Which meant it was almost time for my favorite part of the day."
"Cordula, Emil and I had a daily tradition. Each day at dusk we would meet up in the Town Center and spend time together."
"We had been doing this since we were kids. At first it was just an excuse to ditch our chores, but now it had become a tradition."
"As I approached the center, I saw Cordula and Emil both in the distance. It seemed like I was the last to arrive today. Damn." 

show Emil happy at left
show Cordula happy at right

"Emil walked up to me and pointed an accusatory finger at me."
show Emil smirk
e "What took you so long? I was beside myself with worry."
"He hugged himself. He was trying to look as scared as possible, but I knew his tricks by now."

menu:
    "I..."
    "Felt Annoyed":
        "I gave him a stern glare."
        e "Woah. I was just playing around. No need to look so upset."

    "Played along":
        "I got on my hands and knees and started to beg for forgiveness."
        m "I am ever so sorry Emil. I can't believe I wasted your precious time."
        e "Hm... What shall this peasant's punishment be."
show Cordula frown
c "Cut it out you two."
# Sad sfx here. Possibly
em "Sorry Cordula."
"Cordula's voice cut through our argument. It took us but a second to calm down before Cordula continued."
show Cordula open
c "So, did anything interesting happen to either of you today?"
"I thought for a moment, did anything of note happen today. That woman I met at the stalls came to my mind."
"I looked toward Emil. He also seemed to be in thought."
"Before either of us could respond a hysterical voice rang out. We all looked towards the speaker. "
hide Cordula
hide Emil
show drunk
v "'Tis all true you know!" (cb_mood="yell")
"The man was slurring his words and was flailing about, he was probably just a visiting drunk."
v "I know what I saw. There was most definitely something, something demonic, or what not attacking that woman."
"At this I perked up, maybe there was some merit to this man's rambling."
hide drunk
"Before I could continue this line of thought someone ushered the man back into the local inn."
"For a while none of us spoke until Emil finally broke the silence."
show Emil grim
e "I assume we will be seeing a lot more of those types of people during the festival."
"He tried to play it off as a joke, but the prospect made me worry a bit."
show Emil happy at left with move
show Cordula open at right with move
c "I hope not. Think of the mess that could cause."
"Emil and Cordula continued to argue about whether or not raving drunks was a good thing or a bad thing."
"I did not speak up during the conversation; I could not get my mind off that man."
"Why would a drunken rant turn into a story like that? There had to be some truth to the story."
"Emil and Cordula had stopped arguing and were giving me curious looks."
show Cordula frown
c "Are you feeling tired? Should we leave it for today?"
"Cordula gave a concerned look, and looked towards Emil."
c "Right, Emil?" 
"Emil was staring off. When he heard Cordula's voice he seemed to remember where he was."
show Emil happy
e "Yeah, I was getting tired too. I think I am going to head back."
"I agreed with them, and with that we parted for the day."

hide Emil with fade
hide Cordula with fade
label Night:
play audio "audio/SFX_footstep_dirt.FLAC"
scene black
"I went home and immediately went to my bed. I was exhausted from all the prep work I did today and it was already fairly late." 
"I fell asleep with little struggle."
play audio "audio/Wake.mp3"
show screen day_notify("Start of Day 1")
# MC bedroom Placeholder in future?
"I awoke to a wolf howling in the distance."
"It did not bother me too much, since it was just about time for me to make my way over to the stand."
"I got dressed for the day and left my home with little fanfare. "
play audio "audio/SFX_footstep_dirt.FLAC"
scene town
"I left my home in a hurry. As I walked along the empty streets I heard a noise."
play audio "audio/Growl.mp3"
"It stopped me in my tracks. I looked around, but failed to see anything out of the ordinary so I continued to make my way to the stand."
play audio "audio/SFX_footstep_dirt.FLAC"
scene Stalls with fade
"Since I had prepped everything yesterday, I had little to do other than get out a few items that were to be displayed directly on the counter." 
"After that was complete, it was just about time for the first day of the festival to begin."
    # add bustling sfx

show screen day_notify("Festival Day 1")
play music festivaltune fadein 1.0
"The crowds came in little time. I tended to the stall with fervor."
"Throughout the day I overheard many different conversations."

menu:
    "I focused in on talk of"

    "The Lake":
        $ Lake = True
        "I heard a couple telling a small group of people about an incident that occurred in the lake."
        "The couple resided on the lake and heard strange splashing noises last night."
        "The husband went out to investigate and saw an abnormal glow in the water."
        "As he moved closer he started hearing a melody. It supposedly had been sung in such a beautiful voice that the man could not help but move even closer."
        "He had almost made it into the water when his wife yelled at him to come back inside."
        "He immediately complied."
        

    "Mysterious Noises in the Streets":
        $ Noises = True
        "I heard a group of kids talking about noises they heard in the street last night."
        "One of the kids lives above one of the local shops, and was out late at a friend's house."
        "On his way back he walked along the main promenade by himself."
        "As he got closer to his home he started to hear a baby's cry. Worried, he started to search around for the source."
        "He reached an alley that seemed to be where the sound was coming from and searched down it."
        "There he found nothing, soon after the cries stopped."
        "With nothing else to do, he headed back to his home like he originally planned."

"The rest of the festival went off with little fanfare. We ended up making a record first-day sale."
"All the day-stalls around me were preparing to close, so I started to do the same."
"As I put the stock away I heard a voice speak up."
w "How do you do Eufrid. How are you doing on this dandy night?"
"I recognized the voice instantly. Walaram. I pulled my head out from under the stall table."
show Walaram happy
m "I'm doing just fine. To what do I owe the pleasure?"
m "Were you looking to buy something? Sorry, but we are closed."
show Walaram question
w "Oh heavens no! I was just wondering if you heard anything interesting while working today."
m "{i} That's a little rude. Is the idea of buying from me so crazy to him?{/i}"

menu:
    "Tell him what you heard":
        show Walaram happy
        if Lake:
            m "All I heard about was someone's cow drowning last night. Nothing too absurd." # this is worded a bit strangely. consider changing in the future
            "Walaram perked up at that."
            show Walaram surprised
            w "Do you happen to know whose it was?"
            m "No, sorry I just overheard some villagers discussing it."
            show Walaram concern
            w "I see. Well, I'm off to do some investigating of my own."
            w "Thanks for the information! You've been a big help!" (cb_mood="yell")
            hide Walaram with fade

        else:
            m "Apparently last night a group of kids heard some strange noises."
            m "The kid claimed it sounded like a baby, but when he went to search for the voice he couldn't find anything."
            m "Eventually the cries stopped and the kid went home."
            show Walaram surprised
            w "Interesting... Do you happen to know the name of the kid?"
            m "No, sorry I just overheard some kids talking about it."
            w "Well, thanks anyway! You've been a big help!" (cb_mood="yell")
            hide Walaram with fade

        "With that parting thanks Walaram ran off."
        m "{i}Typical Walaram...{/i}"

    "Don't tell him":
        m "I didn't hear anything, I was too busy working to focus on something like that."
        show Walaram concern
        w "I see..."
        hide Walaram with fade
        "After that he dejectedly walked away."
    # figure out if you want to actual have a conversation here.

"My energy was all but drained, but I still had to go and meet up with Cordula and Emil."
stop music fadeout 1.0

label Night1:
scene Fountain_Night with fade
play audio "audio/SFX_footstep_dirt.FLAC"
show screen day_notify("Night 1", icon="images/Moon.png")
"When I reached the fountain, only Cordula had arrived. She was sitting on the fountain cleaning her harmonica."
"The sun was just about to set and the fountain was awash with the colors from the sky. She looked up as I got closer."
show Cordula happy with fade
m "Seems like Emil is the loser today."
show Cordula surprised
c "Seems like it... Sorry I did not get a chance to stop by your stall today."
m "It's okay. Were you able to get a lot of tips today?"
"Cordula had been planning on playing at the fountain most of the day, which is probably how she managed to beat me here."
show Cordula open
c "I think I got the most tips I have ever gotten. I made a good choice in bringing out my harmonica."
c "A lot of the outsiders have never seen something like it, so I was able to garner a great crowd."
play audio "audio/SFX_footstep_dirt.FLAC"
"A crash could be heard from the distance. I looked behind me to see Emil, fallen into a bush."
"It seemed like he had been trying to sneak up on us but had gotten too nosy. He brushed himself off then made his way over to us."
show Cordula happy at left with move
show Emil sad at right with move

e "Good evening you two. Having all this fun without me?"
show Emil smirk
"Emil tried to play it off like we hadn't seen him in a bush naught but a couple seconds ago."
show Cordula surprised
c "Eufrid only arrived a couple of minutes ago. We have not had too much time to talk."
"Emil again tried to act as though he was not listening in on us."
e "I see, well now that I am here let us truly begin!" (cb_mood="yell")
e "I am sure you both had as exciting days as myself. I must have made a hundred loaves of bread."
"Emil wiped non-existent sweat off his brow."
c "I made quite a fair bit of coin today. It seems the novelty of the harmonica is not lost on the tourists."
show Emil happy
e "What about you Eufrid? How'd the stall go?"
m "We made a record profit! I also overheard some interesting rumours. I was thinking we could explore those tonight."
"When we were younger, we all used to try and explore anything mysterious that occurred in Kleinsee."
"Now that we were older, we of course didn't do this very often."
"But those rumours I heard today, had me intrigued."

if Lake:
    jump lake_start
else: 
    jump street_start

label lake_start:
    "I told Emil and Cordula what I heard about the lake."
    show Emil smirk
    e "Sounds interesting. I can barely remember the last time I visited the lake."
    show Cordula open
    c "'Tis getting quite dark. I should do well to grab a lantern."
    hide Cordula with fade
    hide Emil with fade

    "Cordula went towards her home. Leaving Emil and I alone for but a couple of minutes."
    "We casually spoke about what else occurred in our respective days."
    "It did not take long for Cordula to return. Her home was located next to the chapel in town, not too far at all from the fountain."
    scene Stalls_Night
    "We went towards the lake with Cordula's lamp lighting our way, passing by the now empty stalls as we walked."
    "We had to walk through the forest to reach the lakeshore."
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Forest_Night
    "As a child, I had always been afraid of the forest. I eventually got over that fear, but still found it frightening to walk alone at night in there."
    "Luckily I wasn't alone tonight."
    "Eventually, we reached the shore of the lake."
label lake:
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Lake
"This was the first time I had seen the lake at night since I was a child."
"There used to be a festival that took place near the lake, but ten years ago they stopped doing it."
"I was still young then, so I did not quite know the reason why. Even now I never searched for an answer."
show Emil grim
e "Wow, the lake is a little eerie at night, ain't it?"
"Emil broke the silence, his voice shaking a bit. He had never been great with the night, even now as an adult."
"Though, I would tend to agree with what he said. There was a certain vastness to lakes in the dark." 
hide Emil 
show Cordula happy at left
show Emil happy at right

c "Let us investigate this as quickly as possible. We all still have to work tomorrow."
"Wasting time was never Cordula's forte. With that we got to work."
hide Cordula
hide Emil

screen lake():
    imagemap:
        ground ("images/Lake1.png" if "Glow" in investigated else "images/Lake1.png")
        hover "images/LakeGlow.png"
        hotspot (4, 371, 530, 181) action Return("Fence") tooltip "Fence"
        hotspot (646, 26, 1245, 428) action Return ("Forest") tooltip "Forest"
        if "Glow" not in investigated:
            hotspot (1511, 549, 351, 150) action Return ("Glow") tooltip "?"


    $ tooltip = GetTooltip()
    if tooltip:
        text "[tooltip]" xalign 0.5 yalign 0.75

label lake_loop:
    show screen day_notify("Night 1 Investigation", icon="images/Moon.png")
    call screen lake
    $ spot = _return

    if spot == "Fence":
        "They installed this fence here a couple of years ago. They still look quite new"
        "I felt the cold metal of the bars. The autumn chill had made them extremely cold."
        "Other than that I didn't feel anything of note."

    elif spot == "Forest":
        show Emil happy
        e "The forest looks so small from this view." 
        m "It hardly even looks like a forest. The trees look like sticks."
        hide Emil with dissolve
        "It's too far away to see anything of note from the forest."
        
    elif spot == "Glow":
        "... What is that in the distance. I didn't see it a second ago." 
        play music sirensong fadein 1.0
        show Cordula surprised
        c "Do you two hear that?"
        "A faint singing could be heard coming from the lake. I was unable to parse out what exactly was being sung."
        show Cordula frown
        "Emil tried to speak but Cordula shushed him before he could get out what he wanted to say."
        "We all stayed quiet, listening to the singing. After a couple of minutes it faded, and with that the glow also faded."
        stop music fadeout 1.0
        hide Cordula with dissolve

    $ investigated.add(spot)

    if len(investigated) == 3:
        jump lake_investigated

jump lake_loop

label lake_investigated:
    m "I think we looked at everything around here. Should we start heading back?"
    show Cordula open with fade
    c "Yes, it is getting quite late."
    hide Cordula
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Forest_Night
    "We made our way back towards the town."
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Stalls_Night
    "Once we arrived it took a while for anyone to speak of the glow we saw, but eventually Cordula brought it up."
    show Cordula open at left with fade
    show Emil happy at right with fade
    c "We are all in agreement that what we saw today was the same phenomenon as what Eufrid heard about today, right?"
    show Emil grim
    e "But none of us were drawn to the water. Or at least I was not. Were you two at all?"
    show Cordula frown
    c "Not particularly, no."
    m "Nor did I"
    hide Emil
    hide Cordula
    "We walked in silence for the rest of the journey. Everyone was still contemplating what that glow meant."
    "We all separated for the night. We didn't have time to think about the implications, we all had to work tomorrow." 
    "As I made my way home I thought back to the voice we heard."
    "It had a cadence to it that I had never heard before. It was almost inhuman."
    jump EndNight1

label street_start:
if Noises:
    "I told Cordula and Emil what I heard about mysterious noises in the street."
    show Cordula surprised at left
    show Emil smirk at right
    c "Sounds intriguing. I was unable to hear such a noise last night though."
    "Cordula lived next to the local chapel. It was also located near the main square."
    show Cordula open
    c "Still I think we should try and investigate. What do you all think?"
    show Emil grim
    e "I see no reason not to. It is too early to go to bed quite yet."
    m "I agree, I am rather curious about these noises. It could be just a kid's ramblings, or it could be something much deeper than that."
    hide Emil with fade
    hide Cordula with fade
    "With that we went off to the town to question other residents and visitors."
    "Gas lamps lined the streets, illuminating the night."
    "They had only been installed recently, most likely to help this year's festival."
    "We soon reached our destination and began to start our questioning."

label Questioning1:
    show screen day_notify("Night 1 Questioning", icon="images/Moon.png")
    if ElderlyWoman and WorkingMan and YoungVisitor:
        jump EndQuestioning1

    menu:
        "Who should I question?"

        "Elderly Woman" if not ElderlyWoman:
            $ ElderlyWoman = True
            "We walked towards an elderly woman. I vaguely recognized her, she had lived in this town for a long time. She might have some interesting information."
            m "Good evening, we were just wondering if you heard any strange noises last night?"
            ow "The only thing I heard last night was my worthless husband's ramblings."
            "I flinched a bit. I didn't expect her to be so honest about that type of thing. Emil started to whisper to me."
            show Emil grim
            e "I do not think she has any information about this. She seems too focused on her personal life."
            "I whispered back."
            m "It certainly seems that way."
            hide Emil
            jump Questioning1

        "Working Man" if not WorkingMan:
            $ WorkingMan = True
            show Cordula surprised
            "Cordula seemed to recognize this man, so she took the initiative."
            show Cordula open
            c "Good evening sir, would you mind if we spoke for a moment?"
            v "I do not see why not. What is the matter?"
            "Cordula seemed to have this handled, so I elected to let her converse with this man."
            c "Last night, did you hear anything out of the ordinary?"
            v "I was working at the Inn all night. I was a welcomer for all the new guests." 
            v "I personally did not hear anything but I heard talk from guests about a strange voice near the entrance of town." 
            show Cordula frown
            "We all gave each other looks. This was the type of information we were looking for. The man continued."
            v "From what I understand it sounded like a young woman, but the voice was strained and raspy."
            v "Quite a frightening tale if you ask me."
            hide Cordula
            "Cordula bid the man farewell."
            jump Questioning1

        "Young Visitor" if not YoungVisitor:
            $ YoungVisitor = True
            "Emil walked up to a young woman. She seemed to be from out of town, or at least she had an air to her like she was." 
            show Emil happy
            e "How do you do?"
            show Emil smirk
            "He attempted to put on a suave act. Cordula and I shared a knowing look."
            "The traveler seemed surprised by Emil's attitude. But none the less spoke with him."
            t "I am doing quite fine, thank you. This town is such a beautiful place."
            "Emil conversed with the woman for a considerable amount of time." 
            show Emil happy
            "After an unquantifiable amount of time Emil finally asked the woman about the noises."
            t "I did hear something strange on the way back to the Inn last night."
            t "It sounded like a combination of a cuckoo and a goat. It was quite a thing to hear late at night."
            t "It gave me a fright, so I hurried back to the Inn."
            show Emil grim
            e "I see, that must have been hard for you."
            hide Emil
            "Emil went back to sweet talking the woman while Cordula and I thought of what to do next." 
            jump Questioning1

label EndQuestioning1:
    "After we spoke to everyone we went over what we found out."
    "We parted for the day on that note, all of us had to work in the morning. So we had to wait to figure out what to do next. There was no need to rush things."
    "I walked home thinking about what I learned today."
    jump EndNight1

label EndNight1:
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene black
    show screen day_notify("End of Night 1", icon="images/Moon.png")
    "With that I reached my home and went to bed."
    "..."
    "I awoke with a start, once again hearing a strange noise outside."

    if Lake:
        jump lake_morn2
    else:
        jump street_morn2

label lake_morn2:
    "This time it did not sound like a wolf. It instead sounded more like a loud splash."
    "My family's home was a ways away from the lake, so I found it rather odd."
    # add noise here
    jump morn2

label street_morn2:
    "This time it did not sound like a wolf. It instead sounded more like a baby crying."
    "My family's home was quite separated from the rest of town, so I found it rather odd to hear a baby."
    # add noise here
    jump morn2

label morn2:
    show screen day_notify("Start of Day 2")
    "I went towards the town center, walking at a hurried pace."
    "What I heard weighed on my mind. It made me feel a bit uneasy."

label Stalls2:
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Stalls with fade
    show screen day_notify("Festival Day 2")
    play music festivaltune fadein 1.0
    "Once I made my way to my stand I started to reorganize it. We had already run out of our stock of scarves so I had to find something else to replace it on the display."
    "I ended up replacing the scarf section with silverware made by a local artisan." 
    "The crowds came in soon after. Even more people showed up today."
    "I was kept busy for the majority of the day. There was a lull in the afternoon, many had elected to take a lunch at that time."
    "During that time I listened around for rumors."
#reword this. 
label rumors2:
    if Second and Lake2 or Noises2:
        jump EndRumors2
menu: 
    "What should I listen for?"
    
    "Gossip"if not Second:
        $ Second = True
        "I listened into gossip from a local group of older women."
        "Apparently the mayor is going to make a grand visit tomorrow."
        jump rumors2
    "Talk of a Cow" if Lake and not Lake2:
        $Lake2 = True
        "I overheard a farmer telling someone about his cow."
        "This morning when the farmer went to check on his herd one of the cows was missing."
        "He searched around all morning. Eventually he went to look by the lake."
        "Near the shore of the lake, he found his cow's body, bloated from water."
        "He concluded it must have walked into the lake and drowned."
        jump rumors2

    "New Arrival" if Noises and not Noises2:
        $Noises2 = True
        "I overheard an older couple talking about their neighbors."
        "Late last night, their neighbor gave birth to a healthy baby boy."
        jump rumors2
label EndRumors2:
    "After that lull, the crowds came back in full force."
    "Throughout the rest of my time working the stall I didn't have any more strange encounters."
    "I was able to sell even more products than the prior day, so I ended the day rather cheerful."
    scene Stalls_Night with fade
    stop music fadeout 1.0
    "Soon the end of the day had come and I started to stow away my products. With my head under the table I heard a voice calling me."
    "I went to greet the stranger and hit my head on the table as I arose."
    m "Ouch..."

s "Are you quite alright?"
show Siofra open
"It was then that I saw her, the strange woman I had met prior. Siofra."
m "I'm fine. Shouldn't leave a bump or anything. Did you need something?"
s "I just wanted to wish you well for the rest of the festival."
"She then reached for something out of her pocket. She held up a small bag and plopped it on the table."
s "Here. For you."
"I gave her a befuddled look."
show Siofra
m "Why are you giving me this..."
"I went to inspect the bag. Inside I found small marbles. They had a beautiful sheen to them unlike anything I had ever seen before."
m "Bag of marbles?"
"I hadn't played with such a thing since I was a kid. It felt a little odd to be given something so suddenly, and by a stranger no less." 
show Siofra open
s "I thought you might need them later, they're very nice marbles, see?"
show Siofra
"I wasn't the type to turn down a gift so I pocketed the marbles."
m "Thank you? If you want you can stop by the stall tomorrow, I may be able to give you something in return."
"I figured once the festival was over we would have some things left over. I could find a little something to give to Siofra."
show Siofra open
s "You don't need to do all that. Think nothing of this gift." 
hide Siofra with fade
"Before I could get another word Siofra turned around and left with great haste."
"The encounter left a strange taste in my mouth. I didn't know what to make of it."

label Fountain_Night2:
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Fountain_Night
    show screen day_notify("Night 2", icon="images/Moon.png")

"I was the first one at the fountain tonight. I went to lean against the fountain."
menu: 
    "While waiting I..."
    
    "Pulled Out the Marble Bag":
        $ Marble = True
        "I pulled one of the marbles out of the bag and took a closer look at it."
        "All the marbles were blue with swirls of different colors in them."
        "They were honestly quite beautiful. But I couldn't get Siofra's words out of my mind."
        "Why would I need these?"
        jump Night2
    "Checked the Stall Ledger":
        $Ledger = True
        "I pulled out the ledger from today and reviewed how much we sold."
        "Apparently our bestselling product today was hairpins. I knew something like that would be a success!" 
        m "{i}My father originally didn't want to see something targeted towards women but I convinced him that the market was large enough.{/i}"
        m "{i}I'm happy I was proven correct.{/i}" 
        jump Night2

    "Looked Around":
        $LookedAround = True
        "I decided to search around while I wait."
        jump FountainInvestigate


label FountainInvestigate:
screen FountainInvest():
    imagemap:
        ground ("images/Fountain1.png")
        hotspot (1418, 303, 298, 282) action Return("Cat") tooltip "???"
        hotspot (618, 167, 704, 503) action Return ("Fountain_") tooltip "Fountain"
        hotspot (200, 0, 193, 380) action Return ("Alley") tooltip "Alley"

    $ tooltip = GetTooltip()
    if tooltip:
        text "[tooltip]" xalign 0.5 yalign 0.75

label Fountain_Loop:
    show screen day_notify("Night 2 Investigation", icon="images/Moon.png")
    call screen FountainInvest
    $ spot = _return

    if spot == "Cat":
        "I peeked into the bushes."
        play audio "audio/Meow.mp3"
        "A cat jumped out and sauntered away."
        "{i}Probably someone's pet. They should try to be responsible with it.{/i}"

    elif spot == "Fountain_":
        "This fountain has been here for as long as I have been alive."
        "It was made to commemorate some famous person from our village. I can never remember their name though."  

    elif spot == "Alley":
        "I glanced down the alley."
        "It smelt of rotten eggs. Someone must have just dumped their garbage."

    $ investigated2.add(spot)

    if len(investigated2) == 3:
        jump Night2

jump Fountain_Loop
label Night2:
"I felt a tap upon my shoulder and turned around to see Emil."
show Emil smirk
e "The party has arrived."
show Emil smirk with vpunch 
"I shoved Emil off my shoulder. He cried out in faux pain. I hadn't pushed him that hard..."
"I gave him an annoyed glare then burst out laughing."
show Emil sad
"Emil rubbed his shoulder."
show Emil grim
e "That really hurt you know?"
"I ignored his outburst."
m "Have you seen Cordula?" 
show Emil happy
e "I ran into her on the way here. She told me she would be a little late."
"We ended up waiting for Cordula for another fifteen minutes, chatting all the while."
"Soon I saw Cordula lightly jogging towards us from a distance."
show Emil smirk at right with move
show Cordula surprised at left with move
c "Sorry for my tardiness."
"She said, out of breath. She leaned over, trying to recover."
m "It's okay. It wasn't too long."
show Emil happy
e "Yeah."
show Cordula happy
"With that we got to discussing our days."
"I told them about what I heard today"
if Lake2:
    m "This morning a farmer found that one of his cows had drowned to death."
    show Emil grim
    e "I heard about that as well. It was quite a gruesome sight."
    show Cordula surprised
    c "Sounds like it."
    
    
else:
    m "Last night, someone in town gave birth."
    show Cordula surprised
    c "That's pretty rare."
    "Kleinsee was an aging town. It was rare for someone new to be born or for someone new to move in."
    "I think one of the main reasons for this year's festival being so big was to raise our population."
    
"I moved to sit down upon the fountain. In doing so I felt the bag of marbles rattle in my pocket."
"I had almost forgotten they were there. I pulled them out of my pocket and showed Cordula and Emil."
m "One of the visiting vendors also gave me this today."
show Cordula open
c "What is it?"
"I opened the bag and Cordula looked inside."
show Emil happy
e "Wait, let me get a look too!" (cb_mood="yell")
"..."
show Emil sad
e "Huh. So she just gave you a bag of marbles?"
m "Yes, unprompted too. I found it a little odd..."
show Cordula happy
c "Maybe she was just trying to be polite, she is an outsider to this town. It could be normal where she is from."
"That made enough sense to me. I hadn't seen much outside of Kleinsee so who knows what types of cultures are out there."
show Emil grim
e "What was her name?"
m "Siofra. I think it's a foreign name."
"Emil took a step back."
show Emil grim with vpunch
e "That's that weird, scary-looking lady, right?!" (cb_mood="yell")
show Cordula frown
c "No need to yell."
"Cordula glared at Emil."
show Cordula open
c "Some people are probably trying to sleep at this hour. I don't want to upset anyone."
show Emil sad
e "Sorry, I was just a little surprised."
e "I heard rumors about that lady. I heard she came here just to curse this town."
show Cordula surprised
c "And where did you hear that from?"
e "... The tavern."
m "That was just some local drunk's ravings! He probably just doesn't like outsiders!" (cb_mood="yell")
show Emil grim
e "That could be true... But still it's a worrying rumor right?"
show Cordula open
c "If you believe everything you hear I guess you could say that..."
m "I find it a little offensive that you would believe something like that so easily."
"I moved over to Emil and flicked his forehead."
show Emil sad with vpunch
e "Ouch! What was that for."
m "For believing something so easily. The whole point of this festival is to show our town to the world."
m "And here you are trying to tell us that a visitor is doing something nefarious. With no proof, might I add."
hide Emil with dissolve
hide Cordula with dissolve
"We continued to berate Emil for a couple more minutes."
"After that we went our separate ways and I made my way home."
play audio "audio/SFX_footstep_dirt.FLAC"

scene black
show screen day_notify("End of Night 2", icon="images/Moon.png")
"..."
show screen day_notify("Start of Day 3")
"I awoke to the sun's rays blazing into my room."
"I got up in surprise. I overslept!" 
"I hurriedly got ready, throwing my clothes on as fast as possible."
"I ran out the door and made my way towards the stalls."
play audio "audio/SFX_footstep_dirt.FLAC"
scene Stalls
"I was almost there when I heard a voice."
w "Good morning, Eufrid. What's the rush?"
show Walaram happy
m "I can't talk right now, sorry Walaram!" (cb_mood="yell")
hide Walaram with vpunch
"I pushed past him with a little more force than I intended."
w "Woah. I get it."
"By the time he spoke up I was already far past him."
"I reached my stall, fully out of breath and got prepared for the day."
show screen day_notify("Festival Day 3")
play music festivaltune fadein 1.0
"I started the day. No one pointed out my disheveled appearence, so maybe it wasn't as bad as I thought."
"I served a large variety of customers, some were people I saw everyday and others were people I had never seen in my life."
"By noon, I had already sold more product than either of the previous days."
"I had to constantly restock our display products. I spent more time under the table searching for items than actually vending."
"The second I restocked people would come and buy up the entire stock."
"There was only lull during the day."
"A show was set to take place at three, almost all of the stalls were empty."
"I was able to listen in to the conversations had by the few stragglers. "

label rumors3:
        if cat and mayor and Lake3 or Noises3:
            jump EndRumors3
menu: 
    "What should I listen to?" #REWORD PLEASE

    "Wailing in Cornfield"if Noises2 and not Noises3:
        $ Noises3 = True
        "I overheard a group of older gentlemen talking about their farms."
        "Last night, one of them heard a strange wailing noise coming from their cornfield."
        "They ignored it because of how late it was, but when they went to check their fields this morning their crops were all taken."
        "Only the grain had been taken. The man chalked it up to some animal."

        jump rumors3

    "Missing Husband"if Lake2 and not Lake3:
        $ Lake3 = True
        "I overheard a worried young woman talking to her friends."
        "Her husband went out for a late night fishing trip last night and didn't return this morning."
        "She searched the lake and found the same type of fishing line her husband uses strewn across the shore."

        jump rumors3

    "Mayor"if not mayor:
        $ mayor = True
        "I overheard a group of middle-aged men talking about the mayor."
        "Apparently he had been seen heading to the show a couple of minutes ago."
        "After hearing that the men made their way to the show."

        jump rumors3
        
    "Cat"if not cat:
        $ cat = True
        "I heard a noise from an alley near my stall."
        "I looked towards it and saw a small cat. The cat licked it's paws then went deeper into the alley."

        jump rumors3


# For day 3 deaths and such have Cordula go to bakery at night!!!

label EndRumors3:
    "The crowds came back with full force after the show ended."
    "The rest of the afternoon I was frantically running the stall, trying to make sure I didn't fall behind."
    scene Stalls_Night with fade
    "I completed the rest of the day with only a few mistakes."
    "Once I was free from work I made my way to the fountain."
    stop music fadeout 1.0
    "I hoped the rest of the night would be uneventful. I was exhausted from work."

if Lake:
    label Lake_Night3:
    stop music fadeout 1.0 # music wasn't stopping before this is just to make sure.
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Fountain_Night with fade
    show screen day_notify("Night 3", icon="images/Moon.png")
    show Emil happy with fade
    e "What took you so long? I've been here forever!" (cb_mood="yell")
    m "I was working."
    "I didn't have the energy to play along with Emil tonight."
    m "Cordula's not here yet? I thought she was ending early because of the show."
    show Emil grim
    e "Yeah, I thought so too. But I haven't seen her yet."
    hide Emil with fade
    "We sat and waited for a while longer until Emil got fed up."
    show Emil sad
    e "I'm going to ask around about her. Maybe someone saw her go home or something."
    show Emil smirk
    e "You in?"
    "I nodded my head."
    m "I think if I sit here much longer I may fall asleep, so I'm ready to get moving."
    "I got up off the bench and we began our search."
    hide Emil with fade
    jump Night3_Questioning

else:
    label Noises_Night3:
    stop music fadeout 1.0
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Fountain_Night with fade 
    show screen day_notify("Night 3", icon="images/Moon.png")
    "The fountain area was almost fully empty when I arrived."
    "The only people in the area were an older couple who conversing in hushed whispers."
    "I sat on the edge of the fountain, waiting for Emil and Cordula to show."
    "I started to close my eyes when I felt a tap upon my shoulder."
    show Cordula happy with fade
    "I turned to see Cordula standing in front of me."
    c "Is Emil still not here? I figured I'd be the last one here."
    show Cordula frown
    c "Someone offered to buy me a drink at the tavern after my performance so I figured I'd be a little behind everyone else."
    m "I see, still I wonder why Emil isn't here yet." # kinda weird wording
    "I looked towards a clock posted above the door of one the of shops in the area."
    "It was already 9:30. Where could he be?"
    m "Maybe he's not showing tonight?"
    show Cordula open
    c "No matter how callous he usually is, he would of told one of us in advance."
    m "I guess you're right..."
    hide Cordula
    "We spoke for a couple more minutes, debating where he could be."
    "We soon decided that we better search for him." #maybe change this to actual convo?
    c "Let's search together. Wouldn't want one of us to find him then have to search for the other."
    m "True..."

label Search_Night3:

menu:
    "Where should we search?"

    "Search the Bakery" if not Search_Bakery:
        $ Search_Bakery = True
        jump Search_Bakery

    "Search town" if not Search_Town:
        $ Search_Town = True
        jump Search_Town


label Search_Bakery:
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Bakery_Night with fade

label Search_Bakery_loop:
    call screen Bakery_Night
    $ spot = _return

    if spot == "BakedGoods":
        "It's too dark to make out anything on the shelf."

    elif spot == "Doorway":
        "I glanced inside the doorway. Inside it was pitch black."
        "I called out for Emil but didn't get a response."

    elif spot == "Candles":
        "The candles were the only thing lighting up the room."
        "Even with that light, it was still very difficult to see."

    $ investigated3.add(spot)

    if len(investigated3) == 3:
        show Cordula frown
        c "It doesn't seem like Emil is here."
        hide Cordula
        jump Search_Night3

    jump Search_Bakery_loop

label Search_Town:
    scene Stalls_Night
    "We ending up walking towards the stalls."
    "There were still a few stragglers meandering about, so we started to ask them about Emil."

label Night3_Questioning2:

menu:
    "Who should I talk to?"

    "Older couple" if not oldCouple:
        $oldCouple = True
        "We walked up to an older couple. I vaguely recognized them."
        "They had lived here as long as I had been alive. Or at least I assumed as such."
        show Cordula open
        c "Have you two seen Emil?"
        "Cordula seemed quite friendly with them. Maybe they were frequent watchers of her performances?"
        ow "I haven't. Have you dearie?"
        "The woman turned towards her husband."
        om "I bought some bread from the lad yesterday, remember?"
        ow "Oh yes. Sorry dear."
        show Cordula frown
        c "So you haven't seen him today? Only yesterday?"
        om "I guess that's right."
        c "Well, it was nice talking to you anyway."
        hide Cordula
        "We didn't get any useful information out of the couple."
        jump Night3_Questioning2

    "Watchman" if not Watchman:
        $Watchman = True
        "One of the night watchmen was standing near an empty stall."
        "I didn't recognize him. Maybe he was hired just for the festival season?"
        show Cordula happy
        c "Good evening sir. Would it be alright if I asked you a question?"
        wm "You already did, but that's fine. Ask away."
        show Cordula open
        c "Did you happen to see a man wearing a blue shirt and a brown apron?"
        wm "I don't believe I have."
        c "I see, well sorry for taking time out of your day."
        hide Cordula
        "Cordula bowed and then came back to my side."
        show Cordula frown
        c "I thought for sure he would know something."
        c "Isn't it his job to watch over people..."
        m "Yeah..."
        hide Cordula

        jump Night3_Questioning2

    "Walaram" if not WalaramSearch:
        $WalaramSearch = True
        "I saw Walaram in the distance writing something down in his notebook."
        "Once I got close he swiftly looked up. Almost bumping his head into me in the process."
        show Walaram happy
        w "How do you do this evening Eufrid?"
        m "I'm actually in quite a rush right now."
        show Walaram concern
        w "Oh, I see. What's wrong?"
        show Walaram question
        "He got his notebook back out as he asked. Typical."
        m "We haven't seen Emil at all tonight. I was wondering if you had seen him at all."
        show Walaram happy with vpunch
        w "Well, tonight is your lucky night!" (cb_mood="yell")
        w "I actually ran into him earlier today."
        m "Do you have any idea where he might be right now?"
        show Walaram surprised
        w "I was just getting to that, hold your horses."
        w "Just a while ago he rushed past me mumbling something about a field."
        w "He seemed to be in a strange mood so I tried to get his attention..."
        show Walaram concern
        w "But sadly, he ignored me."
        hide Walaram
        show Cordula open
        "Cordula gently pulled me aside."
        c "He must've went to investigate that field we heard about."
        show Cordula frown
        c "Why would he try to do it alone though..."
        show Cordula frown at left with move
        show Walaram surprised at right with move
        w "What are you two whispering about? Right in front of my face no less."
        m "Sorry, but we have to run. See you later."
        hide Cordula 
        hide Walaram
        w "Wait! What are you two up to!"(cb_mood="yell")
        "We both ignored Walaram and ran towards the field with great haste."
        jump EndSearch_Night3
   
label EndSearch_Night3:
    scene Stalls_Night with fade
    "We rushed through the stalls. Not even stopping to catch our breath."
    "We were both thinking the same thing, {i} why would Emil do this. {/i}"
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Forest_Night with fade
    "Eventually, we made it to the forest."
    "The farm was located just past it. We were almost there!"
    show Cordula frown with vpunch
    c "Just a little further..."
    "Cordula was very much out of breath. She wasn't used to getting this much exercise."
    m "Yeah..."
    hide Cordula with fade
    "We continued to push forward until we eventually made it to the field."
    scene Field_Night
    "It was eerily quiet in the field."
    "The only noises that could be heard were our breaths and crickets chirping."
    "Cordula and I caught our breaths before we started to call out for Emil."
    show Cordula open with vpunch
    c "Emil!" (cb_mood="yell")
    show Cordula open with vpunch
    c "Are you out here?!" (cb_mood="yell")
    hide Cordula
    "While Cordula called out I searched through the crops."
    "After a couple minutes of searching I found something."
    "It was a piece of brown cloth, covered in blood." with vpunch
    "I froze in my tracks and called for Cordula."
    "I quickly realized that I hadn't heard Cordula for the last couple of minutes."
    "I turned around, and saw that she was gone."
    m "Cordula? Where did you go?!" (cb_mood="yell") with vpunch
    # growl go here
    "In the distance, I heard a growling sound."
    "I saw something rustling within the crops and made a run for it."
    m "Cordula?! That wasn't you was it?" with vpunch
    # add squelsh sound here(?)
    "I felt something beneath my feet as I ran."
    "I paused and looked down to see a pool of red."
    "To the left of the pool, sat a torn blue bandana."
    m "..." with vpunch
    "I had to keep moving forward. I needed to leave as soon as possible."
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Forest_Night
    "I continued down the path we had came. Eventually reaching the forest once again."
    "I ran, and I ran, and I ran. Refusing to look back."
    "I could still hear the growling in my ears."
    "I couldn't tell if it was real or I was just hearing things."
    "It sounded close but also felt so far away."
    jump EndOfDay3
    


label Night3_Questioning:
    if youngwoman and Drunk and EmilDay3:
            jump Night3_QuestioningEnd

    "We wandered around the town aimlessly for a bit. Before deciding to ask around"

menu:
    "Who should I talk to?"

    "Young woman" if not youngwoman:
        $ youngwoman = True
        m "Have you seen a short woman wearing a blue bandana?" # See if anyone has any ideas on color
        yw "I actually have. Was she the one performing here earlier?"
        m "Yes! That should be her? Do you know where she went?"
        yw "After she finished her song, she said she had to stop early to go check something out at the lake."
        "That's odd. Why would she need to go there?"
        m "I see. Thanks for the information!"

        jump Night3_Questioning
    "Drunk man" if not Drunk:
        $ Drunk = True
        show drunk with vpunch
        "A man shoved himself into me. I looked up to see the man I heard the other day."
        v "Excuse you!" (cb_mood="yell")
        "The man slurred his words. He seemed quite intoxicated."
        "I internally debated even trying to talk to him, but I was too worried about Cordula to avoid it."
        "I bowed towards the man."
        m "Sorry about that. I was just searching for my friend. In my rush, I didn't see you."
        v "Hmmm, I see."
        m "Have you see a woman wearing a blue bandana around here?"
        v "No, I just got here. The stupid tavern owner kicked me out so I decided to come sit by the fountain."
        "I winced, that makes sense, I wouldn't want this man in our store either..."
        m "I see. Thanks anyways!"
        hide drunk
        "I was able to escape from the drunk before he trapped me in a conversation."

        jump Night3_Questioning

    "Emil" if not EmilDay3:
        $ EmilDay3 = True
        show Emil grim with fade
        m "So you don't have any idea where she could be?"
        e "No idea. I haven't seen her since yesterday"
        m "Same. That's a little worrying..."
        
        jump Night3_Questioning

label Night3_QuestioningEnd:
    show Emil happy with fade
    m "It seems like we need to pay the lake a visit."
    show Emil grim
    e "It seems that way. Why would she go somewhere so spooky at this time?"
    "Emil shivered."
    hide Emil with fade
    "I wanted to get this over with as soon as possible, so I ignored Emil's complaints and pushed forward."
    "He trailed behind me the entire way."
    scene Stalls_Night
    play audio "audio/SFX_footstep_dirt.FLAC"
    "We passed the stalls. All of them were empty at this hour."
    "The streets themselves were also empty. Which I found a little odd."
    scene Forest_Night
    play audio "audio/SFX_footstep_dirt.FLAC"
    "Soon we were walking in the forest, Emil grabbed my hand in fear."
    show Emil grim
    e "Sorry, I'm just a little freaked out right now."
    m "It's fine."
    "His palms were extremely sweaty."
    "We soon arrived at the lake."
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Lake_Cordula
    "When we arrived I could hear a voice in the distance."
    play music sirensong fadein 1.0
    "It sounded exactly like the singing we heard the other day."
    "I started to look for the voice."
    show screen day_notify("Night 3 Investigation", icon="images/Moon.png")
    call screen Lake_Cordula
    $ spot = _return

    if spot == "Fence2":
        "The voice doesn't seem to be coming from there."

    elif spot == "Forest2":
        "I can't hear anything coming from the forest."
        
    elif spot == "Cordula":
        "..."
        #possible shock sfx
        # possible zoom effect in future?
        "In the water, I saw some sort of cloth."
        "It took me a second to realize what it was. I could recognize that outfit anywhere."
        m "What is that?!" (cb_mood="yell")
        show Emil grim
        e "...Huh?" (cb_mood="yell")
        hide Emil with fade
        "We both came to the same conclusion quickly."
        "I scanned around the rest of the lake. Looking for more signs of Cordula."
        "The singing continued on in the background, but it was an afterthought in my mind right now."
        stop music fadeout 1.0
        jump CordulaFound

label CordulaFound:
    stop music fadeout 1.0 # another check to make sure music is actually stopping
    "Emil snapped out of his trance suddenly."
    show Emil grim
    e "I have to get out of here. I can't stay any longer."
    "He spoke with an almost inhuman voice."
    "I had never heard him speak in such a way before."
    "It frightened me a bit."
    hide Emil with vpunch
    "He rushed past me. His eyes looked extremely out of focus."
    play audio "audio/SFX_footstep_dirt.FLAC"
    scene Forest_Night with vpunch
    "I tried to follow after him, but I quickly lost him in the trees."
    "I called out for him for a couple of minutes, while still continuing down the path."
    "Soon, I took a break and rested against a tree."
    "I had been running around for quite a while, so I was out of breath."
    "I put my lantern down on the side of the tree."
    "When I did so, something caught my eye."
    # surprise sfx?
    "I saw Emil's apron, covered in blood."
    "I quickly grabbed my lantern and went back to calling for him, this time more frantically."
    "I wore myself out quickly, so I decided to run back towards the town for help."
    play audio "audio/SFX_footstep_dirt.FLAC"

label EndOfDay3:
    scene Stalls_Night with vpunch
    "Once I made my way to the town, I immediately ran into a familiar face."
    show Siofra with vpunch
    "I grabbed onto Siofra's arm desperately. I was still out of breath so it took me a second to speak up."
    m "-Help, it's Emil a-and Cordula."
    "My voice shook as I spoke."
    "Siofra gave me a curious look."
    s "Why don't you just use the marbles?"
    "She said that as if it was an obvious solution, but I had no idea what she meant."
    m "What?!" (cb_mood="yell")
    show Siofra open
    s "The marbles. Why don't you roll them?"
    hide Siofra
    "Again, she spoke as if this was the best possible solution."
    "It stunned me into silence."
    m "..."
    "I almost ran away from her, but I considered her words for a second."
    "She seemed very confident in her answer, she couldn't of been joking."
    "I had no real clue of where to go from here. Why shouldn't I listen to her."
    "It felt like I was in a pit with no escape, and her voice was the only thing currently grounding me."
    "With that thought in mind. I took out the bag of marbles and rolled one on the ground."
    scene black
    "End of Day 3."
    "..."
    "Start of Day x" #CHEESY ASF
    #maybe prompt players with an option here?
    # when loop starts again, eufrid now runs into Cordula and Emil on the way to the festival. Possibly have her run into Walaram first? or have walaram appear after seeing Cordula and Emil
    # have eufrid see siofra. siofra = vagueposting queen. doesn't seem to necessarily know whats up with eufrid. 
return